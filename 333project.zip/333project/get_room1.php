<?php
require_once 'config.php'; // Database connection

if (isset($_GET['id'])) {
    $room_id = $_GET['id'];

    // Fetch the room details
    $stmt = $pdo->prepare("SELECT * FROM rooms WHERE id = ?");
    $stmt->execute([$room_id]);
    $room = $stmt->fetch();

    if ($room) {
        echo json_encode($room);
    } else {
        echo json_encode(['error' => 'Room not found']);
    }
} else {
    echo json_encode(['error' => 'Invalid request']);
}
?>
<?php
session_start(); //session start

include 'includes_db.php';

if (!isset($_SESSION['user_id'])) { //check if user is logged in, if not go to log in page
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id']; //user_id = id of currently logged in user

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $f_name = htmlspecialchars(trim($_POST['fName'] ?? ''));
    $l_name = htmlspecialchars(trim($_POST['lName'] ?? ''));
    $email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);

    //handle file upload
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
        $target_dir = "uploads/";

        //ensure the uploads directory is there
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true); // Create the directory with appropriate permissions
        }

        $file_name = basename($_FILES['profile_picture']['name']);
        $target_file = $target_dir . $file_name;

        //move uploaded file
        if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $target_file)) {
            //update profile picture in the database
            $query = $pdo->prepare("UPDATE users SET profile_picture = ? WHERE id = ?");
            $query->execute([$target_file, $user_id]);
        } else {
            echo "<p>Error uploading file. Please try again.</p>";
        }
    }

    if ($f_name && $l_name && $email) { //update user data
        $query = $pdo->prepare("UPDATE users SET fName = ?, lName = ?, email = ? WHERE id = ?");
        $query->execute([$f_name, $l_name, $email, $user_id]);
    } else {
        echo "<p>Invalid name or email. Please correct the form.</p>";
    }
}

$query = $pdo->prepare("SELECT * FROM users WHERE id = ?"); //fetch user data from query
$query->execute([$user_id]);
$user = $query->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="style.css"> <!-- making sure path is correct -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
    <title>Profile</title>
</head>
<body>

<nav class="header"> <!-- header (navigation bar) -->
            <a href="homepageprj.php"><span class="material-icons-outlined">home</span></a>
            <div class="header-left">
                <a href="room_browsing.php"><span class="material-icons-outlined">menu_book</span></a>
                <a href="task6main.php"><span class="material-icons-outlined">bar_chart</span></a>
                <a href="profile.php"><span class="material-icons-outlined">account_circle</span></a>
                <a href="admin_login.php"><span class="material-icons-outlined">shield</span></a>
            </div>
            <div class="header-right">
                <a href="logout.php"><span class="material-icons-outlined">logout</span></a>
            </div>
        </nav>

    <div class="container">
        <h1>Your Profile</h1>
        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label>First name:</label>
                <input class="form-control" type="text" name="fName" 
                       value="<?= htmlspecialchars($user['fName'] ?? ''); ?>"> <!-- making sure $user['name'] is defined -->
            </div>
            <div class="mb-3">
                <label>Last name:</label>
                <input class="form-control" type="text" name="lName" 
                       value="<?= htmlspecialchars($user['lName'] ?? ''); ?>"> <!-- making sure $user['name'] is defined -->
            </div>
            <div class="mb-3">
                <label>Email:</label>
                <input type="email" name="email" 
                       value="<?= htmlspecialchars($user['email'] ?? ''); ?>" 
                       class="form-control"> <!-- making sure $user['email'] is defined -->
            </div>
            <div class="mb-3">
                <label>Profile Picture:</label>
                <input type="file" name="profile_picture" class="form-control">
                <?php if (!empty($user['profile_picture'])): ?> <!-- avoid undefined index -->
                    <img src="<?= htmlspecialchars($user['profile_picture']); ?>" alt="Profile Picture" width="100">
                <?php endif; ?>
            </div>
            <button type="submit" class="btn btn-primary">Update Profile</button>
        </form>
    </div>
</body>
</html>

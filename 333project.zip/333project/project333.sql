-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 10, 2024 at 02:57 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project333`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL,
  `fName` text NOT NULL,
  `lName` text NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `fName`, `lName`, `username`, `password`, `email`, `created_at`) VALUES
(2, 'muna', 'ahmed', 'muna123', '$2y$10$3QwKXG7/j3RGdE5lpwHAdOhAG6nVCggKQ4pYZB/fcDC0VpWKJwwpi', 'muna@uob.edu.bh', '2024-12-10 01:12:28');

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `capacity` int(11) NOT NULL,
  `equipment` text NOT NULL,
  `available_timeslots` text NOT NULL,
  `available_times` varchar(255) DEFAULT NULL,
  `background_image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `name`, `capacity`, `equipment`, `available_timeslots`, `available_times`, `background_image`, `created_at`) VALUES
(4, 'Room A', 30, 'Projector, Whiteboard', '', '9:00-10:00, 10:00-11:00', NULL, '2024-12-10 01:22:48'),
(5, 'Room B', 50, 'Microphone, Speaker, Projector', '', '11:00-12:00, 1:00-2:00', NULL, '2024-12-10 01:22:48'),
(6, 'Room C', 20, 'Whiteboard', '', '9:00-10:00, 3:00-4:00', NULL, '2024-12-10 01:22:48'),
(7, 'Room D', 40, 'Projector, Microphone, Speaker', '', '10:00-11:00, 2:00-3:00', NULL, '2024-12-10 01:22:48'),
(8, 'Room E', 25, 'Whiteboard, Monitor', '', '9:00-10:00, 11:00-12:00', NULL, '2024-12-10 01:22:48'),
(9, 'Room H', 15, 'Whiteboard', '', '8:00-9:00, 3:00-4:00', NULL, '2024-12-10 01:22:48');

-- --------------------------------------------------------

--
-- Table structure for table `room_bookings`
--

CREATE TABLE `room_bookings` (
  `booking_id` int(255) NOT NULL,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `starts_at` datetime NOT NULL,
  `ends_at` datetime NOT NULL,
  `booked_at` datetime NOT NULL,
  `booking_status` enum('booked','cancelled') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `room_bookings`
--

INSERT INTO `room_bookings` (`booking_id`, `room_id`, `user_id`, `starts_at`, `ends_at`, `booked_at`, `booking_status`) VALUES
(1, 8, 1, '2024-12-03 09:00:00', '2024-12-03 09:50:00', '2024-12-01 12:00:00', 'booked'),
(2, 9, 5, '2024-09-05 03:00:00', '2024-09-05 03:50:00', '2024-09-09 11:20:00', 'booked'),
(3, 6, 4, '2024-10-21 03:00:00', '2024-10-21 03:50:00', '2024-10-17 18:30:00', 'booked'),
(4, 4, 5, '2024-12-14 10:00:00', '2024-12-14 10:50:00', '2024-12-12 09:00:00', 'booked'),
(5, 5, 3, '2024-12-19 11:00:00', '2024-12-19 11:50:00', '2024-12-15 02:00:00', 'booked'),
(6, 4, 3, '2024-12-24 09:00:00', '2024-12-24 09:50:00', '2024-12-19 08:30:00', 'booked'),
(7, 6, 1, '2024-12-31 03:00:00', '2024-12-31 03:50:00', '2024-12-21 01:00:00', 'booked'),
(8, 7, 5, '2025-02-05 02:00:00', '2025-02-05 02:50:00', '2025-01-31 07:30:00', 'booked'),
(9, 4, 1, '2025-02-09 09:00:00', '2025-02-09 09:50:00', '2025-02-08 09:00:00', 'booked'),
(10, 4, 1, '2024-12-09 09:00:00', '2024-12-09 09:50:00', '2024-12-08 08:00:00', 'booked'),
(11, 9, 5, '2024-12-09 08:00:00', '2024-12-09 08:50:00', '2024-12-07 06:00:00', 'booked'),
(12, 9, 4, '2024-12-09 03:00:00', '2024-12-09 03:50:00', '2024-12-07 05:30:00', 'booked'),
(13, 7, 5, '2024-12-09 10:00:00', '2024-12-09 10:50:00', '2024-12-08 06:00:00', 'booked'),
(14, 4, 1, '2024-12-28 09:00:00', '2024-12-28 09:50:00', '0000-00-00 00:00:00', 'booked'),
(15, 6, 6, '2024-12-10 03:00:00', '2024-12-10 03:50:00', '0000-00-00 00:00:00', 'booked'),
(16, 9, 4, '2025-01-01 08:00:00', '2025-01-01 08:50:00', '0000-00-00 00:00:00', 'booked'),
(17, 5, 3, '2025-01-02 11:00:00', '2025-01-02 11:50:00', '0000-00-00 00:00:00', 'booked'),
(19, 9, 8, '2025-01-06 08:00:00', '2025-01-06 08:50:00', '0000-00-00 00:00:00', 'booked'),
(20, 6, 8, '2025-01-07 09:00:00', '2025-01-07 09:50:00', '0000-00-00 00:00:00', 'booked');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `fName` text NOT NULL,
  `lName` text NOT NULL,
  `id` int(200) NOT NULL,
  `username` varchar(150) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `profile_picture` mediumblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`fName`, `lName`, `id`, `username`, `email`, `password`, `profile_picture`) VALUES
('lara', 'ali', 1, 'lara1', '123@example.com', '$2y$10$PGeZ36ORQ9eGN7tZuAQdjuPecYN85Re6xFR4b8d9qMc0qX99HCO.a', ''),
('jassim', 'adel', 3, 'abcd', '1234@example.com', '$2y$10$CTcmjsQGKKx9YLE.u3.3auovUrHy1mFFPiQqxcJJaAuM1cdb3n2ZS', ''),
('noora', 'mohammed', 4, 'abcde', '12345@example.com', '$2y$10$kXZcuqOVsP0SD2uhwukSxu/ePomVBYrYDIPNHUwdPkBSc0UbixyZi', ''),
('ali', 'rashed', 5, 'Nikhil', 'nikhil@example.com', '$2y$10$9xwd0EGaX4ntG5Zth.Gij.bDOHJb8Jf2cP9Ewqop1IK9gqxieOs6e', ''),
('random', 'person', 6, 'randper1', 'rperso@uob.edu.bh', '$2y$10$UUih1rcgFQ/e13Dp7TSMu.ZbUVjgt4ErBQTpePbqYzlwLws/Df/VS', ''),
('hello', 'hi', 7, 'hello333', 'hello@uob.edu.bh', '$2y$10$tElswWWi.rtmLt5vs1jHp.bPiyQ90jyPZBNmgji06jBtveiM2ff/6', ''),
('mayada', 'rashed', 8, 'maya123', 'maya@uob.edu.bh', '$2y$10$ZIUeqj1G1thecpVmjbHFeeLfEJG78GXOmYkgH7IeUNP79dnVk8wVC', 0x75706c6f6164732f302d6f3230773534757178777063312e77656270);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `room_bookings`
--
ALTER TABLE `room_bookings`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `room_bookings`
--
ALTER TABLE `room_bookings`
  MODIFY `booking_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
